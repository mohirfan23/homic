<aside class="right-side">
            <!-- Main content -->
            <section class="content-header">
                <h1>Pembayaran Listrik</h1>
                <ol class="breadcrumb">
                </ol>
            </section>
            <!-- BEGIN SAMPLE TABLE PORTLET-->
                        <div class="portlet box primary">
                            <div class="portlet-body flip-scroll">
                                <table class="table table-bordered table-striped table-condensed flip-content">
                                    <thead class="flip-content">
                                            <tr>
                                                <th>Nomer</th>
                                                <th>Id Socket</th>
                                                <th>Id Gateway</th>
                                                <th>KWH</th>
                                                <th>Harga (Rp)</th>
                                                <th>Delete</th>
                                            </tr>
                                    </thead>
                                <tbody>
                                    <?php 
                                    $no = 1;
                                    foreach ($bayar as $bayar_listrik): ?>
                                      <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $bayar_listrik->id_socket  ?></td>
                                        <td><?= $bayar_listrik->id_gateway  ?></td>
                                        <td><?= $bayar_listrik->kwh ?></td>
                                        <td>Rp <?= $bayar_listrik->harga  ?></td>
                                        <td>
                                        <a href="<?= site_url('C_bayar_listrik/delete_listrik/'.$bayar_listrik->id_bayar_listrik); ?>" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                      </tr>
                                    <?php endforeach ?>
                              </tbody>
                        </table>
                    </div>
                </div>
                        <!-- END SAMPLE TABLE PORTLET-->
        </aside>
        <!-- right-side -->
    </div>